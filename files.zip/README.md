# WHYPLAN

오답 이미지와 내가 생각한 풀이 과정을 입력하면, Gemini API가 오답의 원인을 다각도로 분석해
아래 8가지 카테고리 중 가장 적합한 키워드를 자동으로 매칭하고, 정밀 피드백과 유사 유형 극복
솔루션을 제공하는 웹앱입니다.

```
#계산 실수형   #개념 혼돈형   #조건 누락형   #시간 부족형
#문제 해석 오류형   #찍기형   #개념 암기 부족형   #집중력 저하형
```

## 화면 구성

| 화면 | 설명 |
|---|---|
| 홈 (`_1`) | 오답 등록 버튼, 오늘의 요약, 보관함 미리보기 |
| 오답 등록 · 분석 (`_2`) | 이미지 업로드 → 내 풀이 입력 → NEXT → Gemini 분석 → 결과 확인 → 저장 |
| 오답 보관함 메인 (`_4`) | 8개 키워드 폴더와 폴더별 누적 건수 |
| 상세 리스트 (`_3`) | 선택한 키워드에 누적된 오답을 최신순으로 나열 |

디자인은 "Academic Clarity" 톤(밝고 미니멀한 톤 + 오답노트의 빨간 여백선을 모티프로 한
포인트 컬러)을 기반으로 했습니다.

## 프로젝트 구조

```
whyplan/
├── index.html          # 프론트엔드 (단일 페이지, 빌드 도구 불필요)
├── api/
│   └── generate.js      # Gemini API를 호출하는 Vercel 서버리스 함수
├── package.json
├── .gitignore
├── LICENSE
└── README.md
```

- 프론트엔드는 순수 HTML/CSS/JS로 작성되어 있어 별도의 빌드 과정이 필요 없습니다.
- 오답 데이터는 현재 사용자의 브라우저 `localStorage`에 저장됩니다(로그인/서버 DB 없이
  바로 동작하는 MVP 구성). 여러 기기 간 동기화나 계정 기능이 필요하다면 `index.html`의
  `Store` 객체를 데이터베이스 연동 API 호출로 교체하면 됩니다.
- Gemini 호출은 반드시 서버(`api/generate.js`)에서만 이루어지며, API 키는 브라우저에
  절대 노출되지 않습니다.

## 로컬에서 실행하기

1. [Vercel CLI](https://vercel.com/docs/cli)를 설치합니다.

   ```bash
   npm i -g vercel
   ```

2. 프로젝트 루트에 `.env` 파일을 만들고 Gemini API 키를 입력합니다.

   ```bash
   GEMINI_API_KEY=your_gemini_api_key_here
   ```

3. 로컬 개발 서버를 실행합니다.

   ```bash
   vercel dev
   ```

4. 브라우저에서 `http://localhost:3000` 접속

## Vercel 배포하기

### 방법 A — Vercel CLI

```bash
npm i -g vercel
vercel            # 최초 배포 (질문에 답하며 프로젝트 생성)
vercel --prod     # 프로덕션 배포
```

### 방법 B — GitHub 연동

1. 이 폴더를 GitHub 저장소로 push 합니다.
2. [vercel.com](https://vercel.com) → **Add New Project** → 해당 저장소 선택
3. Framework Preset은 **Other**로 두면 됩니다(별도 빌드 명령 불필요).
4. 배포 완료 후 아래 "환경변수 설정"을 진행합니다.

### 환경변수 설정 (필수)

Vercel 대시보드 → 프로젝트 → **Settings → Environment Variables** 에서 다음을 추가하세요.

| Key | Value | Environment |
|---|---|---|
| `GEMINI_API_KEY` | Google AI Studio에서 발급받은 Gemini API 키 | Production / Preview / Development |

환경변수를 추가한 뒤에는 **Redeploy**를 한 번 실행해야 반영됩니다.

Gemini API 키는 [Google AI Studio](https://aistudio.google.com/app/apikey)에서 무료로
발급받을 수 있습니다.

## API 명세

### `POST /api/generate`

**요청 (JSON)**

```json
{
  "imageBase64": "data:image/jpeg;base64,....",
  "mimeType": "image/jpeg",
  "userSolution": "내가 생각한 풀이 과정 텍스트"
}
```

**응답 (JSON)**

```json
{
  "category": "조건 누락형",
  "confidence": "상",
  "feedback": "문제에서 제시된 'x는 자연수' 조건을 고려하지 않고 풀이를 진행했습니다...",
  "solution": "문제를 읽을 때 조건에 밑줄을 긋고, 풀이 전 체크리스트로 확인하는 습관을 들여보세요."
}
```

카테고리 값은 항상 아래 8개 중 하나로 고정됩니다.

```
계산 실수형 · 개념 혼돈형 · 조건 누락형 · 시간 부족형
문제 해석 오류형 · 찍기형 · 개념 암기 부족형 · 집중력 저하형
```

## 기술 스택

- Frontend: 순수 HTML / CSS / JavaScript (프레임워크·빌드 도구 없음)
- Backend: Vercel Serverless Function (Node.js)
- AI: Google Gemini API (`gemini-2.5-flash`, 이미지+텍스트 멀티모달 분석)

## 라이선스

MIT License — 자세한 내용은 [LICENSE](./LICENSE) 파일을 참고하세요.
