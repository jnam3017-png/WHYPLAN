// api/generate.js
// Vercel Serverless Function (Node.js runtime)
// Receives a wrong-answer image + the student's own solution notes,
// calls the Gemini API, and returns a structured analysis:
//   - one matched category out of the 8 fixed keywords
//   - short precision feedback
//   - a solution / practice tip for overcoming that error type
//
// The Gemini API key is read from the environment variable GEMINI_API_KEY.
// It is never hard-coded and never sent to the client.

const CATEGORIES = [
  "계산 실수형",
  "개념 혼돈형",
  "조건 누락형",
  "시간 부족형",
  "문제 해석 오류형",
  "찍기형",
  "개념 암기 부족형",
  "집중력 저하형",
];

const GEMINI_MODEL = "gemini-2.5-flash";
const GEMINI_ENDPOINT = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent`;

module.exports = async function handler(req, res) {
  // CORS (safe default in case the front-end is ever served from a different origin)
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");

  if (req.method === "OPTIONS") {
    res.status(200).end();
    return;
  }

  if (req.method !== "POST") {
    res.status(405).json({ error: "POST 요청만 지원합니다." });
    return;
  }

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    res.status(500).json({
      error:
        "서버에 GEMINI_API_KEY 환경변수가 설정되어 있지 않습니다. Vercel 프로젝트 설정에서 등록해주세요.",
    });
    return;
  }

  try {
    const { imageBase64, mimeType, userSolution } = req.body || {};

    if (!imageBase64) {
      res.status(400).json({ error: "오답 이미지가 전달되지 않았습니다." });
      return;
    }

    const cleanedBase64 = String(imageBase64).replace(/^data:.*;base64,/, "");
    const safeMimeType = mimeType || "image/jpeg";
    const solutionText =
      typeof userSolution === "string" && userSolution.trim().length > 0
        ? userSolution.trim()
        : "(학생이 별도로 작성한 풀이 과정이 없습니다.)";

    const prompt = buildPrompt(solutionText);

    const geminiRequestBody = {
      contents: [
        {
          role: "user",
          parts: [
            { text: prompt },
            {
              inline_data: {
                mime_type: safeMimeType,
                data: cleanedBase64,
              },
            },
          ],
        },
      ],
      generationConfig: {
        temperature: 0.4,
        response_mime_type: "application/json",
      },
    };

    const response = await fetch(`${GEMINI_ENDPOINT}?key=${apiKey}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(geminiRequestBody),
    });

    if (!response.ok) {
      const errText = await response.text();
      console.error("Gemini API error:", response.status, errText);
      res.status(502).json({
        error: "Gemini API 호출에 실패했습니다.",
        detail: errText,
      });
      return;
    }

    const data = await response.json();
    const rawText =
      data?.candidates?.[0]?.content?.parts?.map((p) => p.text || "").join("") ||
      "";

    const parsed = safeParseAnalysis(rawText);

    res.status(200).json({
      category: parsed.category,
      confidence: parsed.confidence,
      feedback: parsed.feedback,
      solution: parsed.solution,
      raw: undefined,
    });
  } catch (err) {
    console.error("generate.js error:", err);
    res.status(500).json({ error: "분석 중 오류가 발생했습니다.", detail: String(err) });
  }
};

function buildPrompt(solutionText) {
  return `당신은 학생의 오답을 분석하는 전문 학습 코치입니다.
아래 이미지는 학생이 틀린 문제(오답)이며, 학생이 직접 작성한 풀이 과정은 다음과 같습니다:

"""
${solutionText}
"""

다음 8개의 고정 카테고리 중에서 이 오답의 근본 원인으로 가장 적합한 "단 하나"의 키워드를 선택하세요:
${CATEGORIES.map((c, i) => `${i + 1}. ${c}`).join("\n")}

반드시 아래 JSON 형식으로만 응답하세요. 다른 텍스트나 설명, 마크다운 코드블록을 절대 포함하지 마세요.

{
  "category": "위 8개 중 정확히 하나 (다른 문자열 금지)",
  "confidence": "상" | "중" | "하",
  "feedback": "이미지와 풀이 과정을 근거로 한 2~4문장의 정밀 피드백. 학생에게 직접 말하듯 다정하지만 명확하게 작성.",
  "solution": "같은 유형의 오답을 다시 반복하지 않기 위한 구체적인 연습법 또는 극복 전략을 2~3문장으로 제시."
}`;
}

function safeParseAnalysis(rawText) {
  let obj = null;
  try {
    obj = JSON.parse(rawText);
  } catch (e) {
    const match = rawText.match(/\{[\s\S]*\}/);
    if (match) {
      try {
        obj = JSON.parse(match[0]);
      } catch (e2) {
        obj = null;
      }
    }
  }

  if (!obj) {
    return {
      category: "집중력 저하형",
      confidence: "하",
      feedback:
        "분석 결과를 정확히 해석하지 못했습니다. 이미지 화질이나 풀이 내용을 조금 더 자세히 입력한 뒤 다시 시도해주세요.",
      solution: "문제 이미지를 선명하게 다시 촬영하고, 본인이 생각한 풀이 과정을 조금 더 구체적으로 적어주세요.",
    };
  }

  const category = CATEGORIES.includes(obj.category) ? obj.category : CATEGORIES[7];

  return {
    category,
    confidence: ["상", "중", "하"].includes(obj.confidence) ? obj.confidence : "중",
    feedback: typeof obj.feedback === "string" ? obj.feedback : "",
    solution: typeof obj.solution === "string" ? obj.solution : "",
  };
}
